These solutions were built in Visual Studio 2015 prior to the full release of the .NET Core tooling. They use project.json files for the project metadata.

