﻿namespace SamuraiAppCore.Domain
{
    public class Quote:ClientChangeTracker
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public Samurai Samurai { get; set; }
        public int SamuraiId { get; set; }
       
  }
}