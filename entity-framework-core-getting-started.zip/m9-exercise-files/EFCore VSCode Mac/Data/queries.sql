select lower(table_name) from information_schema.tables where table_schema='public';

